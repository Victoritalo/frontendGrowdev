const minhaModal = new bootstrap.Modal("#minha-modal", {});
const body = document.getElementById("meu-body");

function abrirModal() {
  minhaModal.show();
}

function fecharModal() {
  minhaModal.hide();
}

function ondeEstaOMouse(event) {
  console.log("Eixo y", event.screenY);

  if (window.screenY < 200) {
    abrirModal();
  }
}

body.addEventListener("mousemove", ondeEstaOMouse, false);
